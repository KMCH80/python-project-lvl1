from brain_games.games import progression
from brain_games import cli


def main():
    cli.play(progression.play)


if __name__ == '__main__':
    main()
