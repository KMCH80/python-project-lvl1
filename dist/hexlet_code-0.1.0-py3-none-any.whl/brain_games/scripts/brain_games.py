#!/usr/bin/env python3
from brain_games import cli

levels = 3
interval = 10


def greet():
    cli.welcome_user()


def main():
    greet()


if __name__ == '__main__':
    main()
